package submission.dicoding.local

import android.util.Log
import androidx.lifecycle.*
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import submission.dicoding.network.*

class RegisterViewModel : ViewModel() {
    private var _registerResponse = MutableLiveData<RegisterResponses>()
    val registerResponse: LiveData<RegisterResponses> = _registerResponse

    fun registerUser(name: String, email: String, password: String){
        val clientRegister = ApiConfig().getApiService().registerUser(name, email, password)
        clientRegister.enqueue(object : Callback<RegisterResponses> {
            override fun onResponse(
                call: Call<RegisterResponses>,
                response: Response<RegisterResponses>
            ) {
                if(response.isSuccessful){
                    _registerResponse.value = response.body()
                    Log.d("RegisterViewModel", "onResponseSuccess: Error= ${response.body()?.error}, Message= ${response.body()?.message}")
                }else{
                    Log.d("RegisterViewModel", "onResponseFailure: ${response.body()?.message}")
                }
            }

            override fun onFailure(call: Call<RegisterResponses>, t: Throwable) {
                Log.e("RegisterViewModel", "onFailure: ${t.message}")
            }
        })
    }
}

class MainViewModel(private val pref: UserPreferences) : ViewModel() {
    private var _loginResponse = MutableLiveData<LoginResponse>()
    val loginResponse: LiveData<LoginResponse> = _loginResponse

    private var _listStoryItem = MutableLiveData<List<ListStoryItem?>?>()
    val listStoryItem: MutableLiveData<List<ListStoryItem?>?> = _listStoryItem

    fun getTokenKey(): LiveData<String>{
        return pref.getTokenKey().asLiveData()
    }

    fun saveTokenKey(token:String){
        viewModelScope.launch {
            pref.saveTokenKey(token)
        }
    }

    fun deleteTokenKey(){
        viewModelScope.launch{
            pref.deleteTokenKey()
        }
    }

    fun loginUser(email: String, password: String){
        val clientLogin = ApiConfig().getApiService().loginUser(email, password)
        clientLogin.enqueue(object : Callback<LoginResponse>{
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if(response.isSuccessful){
                    _loginResponse.value = response.body()
                    Log.d("MainViewModel", "onResponseSuccess: Error= ${response.body()?.error}, Message= ${response.body()?.message}")
                }else{
                    Log.d("MainViewModel", "onResponseFailure: ${response.body()?.message}")
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                Log.e("MainViewModel", "onFailure: ${t.message}")
            }
        })
    }

    fun getStories(token: String, size: Int){
        val clientGetStory = ApiConfig().getApiService().getStories(token, size)
        clientGetStory.enqueue(object : Callback<GetStoryResponse>{
            override fun onResponse(
                call: Call<GetStoryResponse>,
                response: Response<GetStoryResponse>
            ) {
                if(response.isSuccessful){
                    _listStoryItem.value = response.body()?.listStory
                    Log.d("MainViewModel", "onResponseSuccess: Error= ${response.body()?.error}, Message= ${response.body()?.message}")
                }else{
                    Log.d("MainViewModel", "onResponseFailure: ${response.body()?.message}")
                }
            }

            override fun onFailure(call: Call<GetStoryResponse>, t: Throwable) {
                Log.e("MainViewModel", "onFailure: ${t.message}")
            }

        })
    }

}

class ViewModelFactory(private val pref: UserPreferences): ViewModelProvider.NewInstanceFactory(){
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(MainViewModel::class.java)){
            return MainViewModel(pref) as T
        }
        throw IllegalArgumentException("Unknown ViewModel Class: "+ modelClass.name)
    }
}