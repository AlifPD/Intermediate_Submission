package submission.dicoding.view

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import submission.dicoding.R
import submission.dicoding.databinding.*
import submission.dicoding.local.MainViewModel
import submission.dicoding.local.RegisterViewModel
import submission.dicoding.local.UserPreferences
import submission.dicoding.local.ViewModelFactory
import submission.dicoding.network.ListStoryItem

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "session")

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreferences.getInstance(dataStore))
        )[MainViewModel::class.java]

        viewModel.getTokenKey().observe(this) { token ->
            if (token.isEmpty()) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                viewModel.getStories("Bearer $token", 20)
                viewModel.listStoryItem.observe(this) { list ->
                    showStories(list)
                }
            }
        }

        binding.logoutButton.setOnClickListener {
            viewModel.deleteTokenKey()
            startActivity(Intent(this, WelcomeActivity::class.java))
            finish()
        }
        binding.addStoryButton.setOnClickListener {
            startActivity(Intent(this, AddStoryActivity::class.java))
        }
    }

    private fun showStories(list: List<ListStoryItem?>?) {
        binding.rvStories.layoutManager = GridLayoutManager(this, 3)

        val storyAdapter = StoryAdapter(list)
        binding.rvStories.adapter = storyAdapter

        storyAdapter.setOnItemClickCallback(object : StoryAdapter.OnItemClickCallback {
            override fun onItemClicked(data: ListStoryItem?) {
                val toDetailIntent = Intent(this@MainActivity, DetailStoryActivity::class.java)
                toDetailIntent.putExtra("DATA", data)
                startActivity(toDetailIntent)
            }

        })
    }
}

class WelcomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        onButtonClicked()
    }

    private fun onButtonClicked() {
        binding.toLoginButton.setOnClickListener {
            Log.d("Welcome Activity", getString(R.string.login_button_click))
            startActivity(Intent(this, LoginActivity::class.java))
        }
        binding.toSignupButton.setOnClickListener {
            Log.d("Welcome Activity", getString(R.string.signup_button_click))
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }
}

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding
    private lateinit var viewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[RegisterViewModel::class.java]

        binding.signupButton.setOnClickListener {
            val inputName = binding.nameSignupEdittext.text.toString()
            val inputEmail = binding.emailSignupEdittext.text.toString()
            val inputPassword = binding.passwordSignupEdittext.text.toString()

            viewModel.registerUser(inputName, inputEmail, inputPassword)
            viewModel.registerResponse.observe(this) {
                when (it.error) {
                    true -> {
                        Toast.makeText(
                            this,
                            "${it.message}, Harap Coba Lagi",
                            Toast.LENGTH_SHORT
                        ).show()
                        binding.nameSignupEdittext.text?.clear()
                        binding.emailSignupEdittext.text?.clear()
                        binding.passwordSignupEdittext.text?.clear()
                    }
                    else -> {
                        Toast.makeText(
                            this,
                            "Akun Anda Berhasil Dibuat",
                            Toast.LENGTH_SHORT
                        ).show()
                        finish()
                    }
                }
            }

        }
    }
}

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreferences.getInstance(dataStore))
        )[MainViewModel::class.java]

        binding.loginButton.setOnClickListener {
            val inputEmail = binding.emailLoginEdittext.text.toString()
            val inputPassword = binding.passwordLoginEdittext.text.toString()

            viewModel.loginUser(inputEmail, inputPassword)
            viewModel.loginResponse.observe(this) {
                if (it.error == true || it == null) {
                    Toast.makeText(
                        this,
                        "${it.message}, Harap Coba Lagi",
                        Toast.LENGTH_SHORT
                    ).show()
                    binding.emailLoginEdittext.text?.clear()
                    binding.passwordLoginEdittext.text?.clear()
                } else {
                    Toast.makeText(
                        this,
                        "${it.message}, Anda Berhasil Login",
                        Toast.LENGTH_SHORT
                    ).show()

                    viewModel.saveTokenKey(it.loginResult?.token.toString())
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                }
            }
        }
    }
}

class DetailStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val data = intent.getParcelableExtra<ListStoryItem?>("DATA")
        Log.d("DetailStoryActivity", "onDataReceived: $data")

        Glide.with(this)
            .load(data?.photoUrl)
            .into(binding.imgvDetailAvatar)
        binding.tvDetailName.text = data?.name
        binding.tvDetailDesc.text = data?.description
    }
}

class AddStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}

class CameraActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCameraBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}