package submission.dicoding.helper

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Matrix
import submission.dicoding.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

val timestamp: String =
    SimpleDateFormat("dd-MMM-yyyy", Locale.US).format(System.currentTimeMillis())

fun createFile(application: Application): File {
    val mediaDir = application.externalMediaDirs.firstOrNull()?.let {
        File(it, application.resources.getString(R.string.app_name)).apply { mkdirs() }
    }

    val outputDirectory = if (
        mediaDir != null && mediaDir.exists()
    ) mediaDir else application.filesDir

    return File(outputDirectory, "$timestamp.jpg")
}

fun rotateBitmap(bitmap: Bitmap, isBackCamera: Boolean = false): Bitmap{
    val matrix = Matrix()

    return if(isBackCamera){
        matrix.postRotate(90f)
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }else{
        matrix.postRotate(-90f)
        matrix.postScale(-1f, 1f, bitmap.width/2f, bitmap.height/2f)
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}